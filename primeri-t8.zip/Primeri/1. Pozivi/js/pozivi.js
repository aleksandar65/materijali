$(document).ready(function(){
	$("#get").click(function(){
		$.get("https://httpbin.org/get",function(data,status,xhr){
			$("#div1").text(xhr.responseText);
			$("#div2").text(xhr.getAllResponseHeaders());

		});
	});

	$("#getargs").click(function(){
		$.get("https://httpbin.org/get?ime=pera&prezime=peric",function(data,status,xhr){
			$("#div1").text(xhr.responseText);
			$("#div2").text(xhr.getAllResponseHeaders());

		});
	});

	$("#getjson").click(function(){
		/*$.getJSON("https://httpbin.org/get?ime=pera&prezime=peric",function(data,status,xhr){
			$("#div1").text(xhr.responseText);
			$("#div2").text(xhr.getAllResponseHeaders());
		});*/
		$.getJSON("https://httpbin.org/get?ime=pera&prezime=peric").done(function(data,status,xhr){
			$("#div1").text(xhr.responseText);
			$("#div2").text(xhr.getAllResponseHeaders());
		});

	});

	$("#post").click(function(){
		$.post("https://httpbin.org/post",function(data,status,xhr){
			$("#div1").text(xhr.responseText);
			$("#div2").text(xhr.getAllResponseHeaders());

		});
	});

	$("#postargs").click(function(){
		$.post("https://httpbin.org/post",{ime: "pera", prezime: "peric"},function(data,status,xhr){
			$("#div1").text(xhr.responseText);
			$("#div2").text(xhr.getAllResponseHeaders());

		});
	});

	$("#ajaxget").click(function(){
		$.ajax({
			method: "GET",
			url: "https://httpbin.org/get?ime=pera&prezime=peric",
			success: function(data, status, xhr){
				$("#div1").text(xhr.responseText);
				$("#div2").text(xhr.getAllResponseHeaders());
			},
			error: function(data, status, xhr){
				$("#div1").text(xhr.responseText);
				$("#div2").text(xhr.getAllResponseHeaders());
			}
		});
	});

	$("#ajaxgetjson").click(function(){
		$.ajax({
			method: "GET",
			url: "https://httpbin.org/get?ime=pera&prezime=peric",
			dataType: "json",
			success: function(data, status, xhr){
				$("#div1").text(xhr.responseText);
				$("#div2").text(xhr.getAllResponseHeaders());
			},
			error: function(data, status, xhr){
				$("#div1").text(xhr.responseText);
				$("#div2").text(xhr.getAllResponseHeaders());
			}
		});
	});

	$("#ajaxpost").click(function(){
		$.ajax({
			method: "POST",
			url: "https://httpbin.org/post",
			dataType: "json",
			data: {ime: "pera", prezime: "peric"},
			success: function(data, status, xhr){
				$("#div1").text(xhr.responseText);
				$("#div2").text(xhr.getAllResponseHeaders());
			},
			error: function(data, status, xhr){
				$("#div1").text(data.responseText);
				$("#div2").text(status);
			}
		});
	});

	$("#done").click(function(){
		$.ajax({
			method: "POST",
			url: "https://httpbin.org/post",
			dataType: "json",
			data: {ime: "pera", prezime: "peric"},
		}).done(function(data, status, xhr){
			$("#div1").text(xhr.responseText);
			$("#div2").text(xhr.getAllResponseHeaders());
		}).fail(function(data, status, xhr){
			$("#div1").text(data.responseText);
			$("#div2").text(status);
		});
	});

	$("#fail").click(function(){
		$.ajax({
			method: "POST",
			url: "https://httpbin.org/get",
			dataType: "json",
			data: {ime: "pera", prezime: "peric"},
		}).done(function(data, status, xhr){
			$("#div1").text(xhr.responseText);
			$("#div2").text(xhr.getAllResponseHeaders());
		}).fail(function(data, status, xhr){
			$("#div1").text(data.responseText);
			$("#div2").text(status);
		});
	});
});