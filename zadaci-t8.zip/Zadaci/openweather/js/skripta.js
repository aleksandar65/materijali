$(document).ready(function(){
	var appiKey = "appid=3726fe9cef4ab9d506ee77d8d8f7f3d1";
	
});